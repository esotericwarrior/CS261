/* CS261- Assignment 1 - Q.3*/
/* Name: Tristan Santiago
* Date: July 6, 2018
* Solution description: Program which given an input string 
*containing some non-alphabetical character in the middle
* of a string. 
* create the camelCase version of that word, with the
* second word being taken from the space marked character forward */
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <ctype.h>

#define _CRT_SECURE_NO_WARNINGS
#define MAX_STR_SIZE 100

// functional prototypes
char toUpperCase(char ch);
char toLowerCase(char ch);
int stringLength(char s[]);
int testValidString(char *str);
int lettersBeforeAndAfter(char *str, int index);
char *convertInput(char *str);
char *buildString(int *validArrayIndices, char *str);
void camelCase(char *str);
int *findProperIndices(char *str, int index);
void testWord(char *str);
void test();
void FINALcamelCase();

// main function is up top now
int main(){
    /*Read the string from the keyboard*/
    char* userString = (char*)malloc(sizeof(char) * MAX_STR_SIZE);
	printf("Enter string: ");
	scanf(" %[^\t\n]s", userString);
    testWord(userString);
    
    //test();
    return 0;
}

void FINALcamelCase(char* word){
     /*Convert to camelCase*/
     int i, j;
     int size = stringLength(word);
     for(i = 0; i < size; ++i) {
       if(word[i] == '_') {
          word[i] = toUpperCase(word[i+1]);
          for(j = i+1; j < size-1; ++j) {
             word[j] = word[j+1];
         }
         size--;
      }
    }
    word[size] = 0;
}


/* test function which runs through the required strings*/
void test(){
    char *str1 = "_random_ _word";
    char *str2 = "@$random4word";
    char *str3 = " random word ";
	char *str4 = "random  word";
	char *str5 = "RANDOM_Word";
	char *str6 = "435_%7_$$";
    
	testWord(str1);
	testWord(str2);
	testWord(str3);
	testWord(str4);
	testWord(str5);
	testWord(str6);
}

/* iterates through str and converts the right value to uppercase */
void camelCase(char *word){
	if(word == NULL){
		return;
	}
	int i = 0;
	while(word[i++] != '\0'){
		if(word[i] == '_')
			word[i+1] = toUpperCase(word[i+1]);
	}
}

/* converts char to uppercase */
char toUpperCase(char ch){
  /*Convert ch to upper case, assuming it is in lower case currently*/
	if (ch >= 'a' && ch <= 'z') {
		ch = ch - 32;
	}
	return ch;
}

/* converts char to lowercase */
char toLowerCase(char ch){
  /*Convert ch to lower case, assuming it is in upper case currently*/                          
	if (ch >= 'A' && ch <= 'Z') {
		ch = ch + 32;
	}
	return ch;
}

/* returns the length of a string*/
int stringLength(char s[]) {
   /*Return the length of the string*/
	int i = 0;
	while (s[i] != '\0') {
		i++;
	}
	return i;
}

/* convert strings into a form <firstHalf>_<secondHalf> 
 * 1. check that it is a valid string to be converted
 * 2. use an int array to store all the indices of str containig letters 
 * 3. use that array of indices to neatly build a converted string */
char *convertInput(char *str){
	// index of our space character 
	int index = testValidString(str);
	
	// if our string isn't valid 
	if(index == 0){ return NULL; }
	
	// this array is going to do the most important job. Each index of validArrayIndices
	// will contain a matching index of str containing an alphabetical character 
	// unless it is the space character we indexed earlier
	// we allocate memory like usual
	int* indexArray = findProperIndices(str, index);
	
	// we can finally build our string 
	char *convertedString = buildString(indexArray, str);
	
	return convertedString;
}

/* Check that a string is valid to be converted 
 * returns 0 if not valid, 1 if valid 
 * Valid Strings must contain letters before and after some non-alphabetical character 
 * 1. read through the string 
 * 2. for every potential space character, see if it has letters before and after 
 */
int testValidString(char *str){
	int index = 0;
	
	// we will iterate through the whole string 
	while(str[index++] != '\0'){
		
		// found a potential valid space 
		if(isalpha(str[index]) == 0){
			
			// confirm it has letters before and after
			if(lettersBeforeAndAfter(str, index) == 1){
				return index;
			}
		}
	}

	return 0;
}

/* checks if a string has letters before and after a given index 
 * returns 0 if not valid, 1 if valid */
int lettersBeforeAndAfter(char *str, int index){
	int i = 0;
	int lettersBefore = 0;
	int lettersAfter = 0;
	
	// check if a string before
	for(i = index; i >= 0; i--)
		if(isalpha(str[i]) > 0)
			lettersBefore = 1;
		
	// check if a string after
	i = index;
	while(str[i] != '\0')
		if(isalpha(str[i++]) > 0)
			lettersAfter = 1;
	
	
	// return the results 
	if(lettersAfter == 1 && lettersBefore == 1)
		return 1;
	
	return 0;
}

/* construct our string to be of the form <firstHalf>_<secondHalf>
 * use validArrayIndices to only save indices we know have alphabetical characters */
char *buildString(int *validArrayIndices, char *str){
	// string to hold our converted string
	char* convertedString = (char*)malloc(sizeof(char)*MAX_STR_SIZE);
	
	// we had previously stored the length of validArrayIndices in index 0
	int length = validArrayIndices[0];
	int i;
	
	// read through our valid array for the indices not counting 0
	for(i = 1; i < length; i++){
		
		// when we get to our flag, set our _ 
		if(validArrayIndices[i] == -1){
			convertedString[i-1] = '_';
		}
		
		// otherwise, we save a lowercase letter
		else{
			char lowerCase = toLowerCase(str[validArrayIndices[i]]);
			convertedString[i-1] = toLowerCase(str[validArrayIndices[i]]);
		}
	}
	
	return convertedString;
}

/* returns an integer array where each element of the array contains some 
   index of an alphabetical character, except the value -1 represents _ */
int *findProperIndices(char *str, int index){
	int i = 0, j = 1;
	int strlen = stringLength(str);
	int *indexArray = (int *)malloc(sizeof(int)*strlen);
	
	// read through our string 
	for(i = 0; i < strlen; i++){
		// if it contains a valid letter
		if(isalpha(str[i]) > 0)
			indexArray[j++] = i;

		// mark our underscore 
		if(i == index)
			indexArray[j++] = -1;	
	}
	indexArray[0] = j;
	
	return indexArray;
}

/* gives us a print statement for each word that is being tested */
void testWord(char *str){
	printf("string         = %s \n", str);
	
	char *strConvert = convertInput(str);
	/*Call camelCase*/
	printf("string convert = %s \n", strConvert);
	FINALcamelCase(strConvert);
	/*Print the new string*/
	printf("camelcase      = %s \n", strConvert);
	
	printf("\n");
}