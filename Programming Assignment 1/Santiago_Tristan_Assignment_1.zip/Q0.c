/* CS261- Assignment 1 - Q. 0*/
/* Name: Tristan Santiago
 * Date: July 6, 2018
 * Solution description: This program assigns a random number between 0 and 10 to a variable and prints the value
 * and address of the variable. It then follows the assignment instructions using the methods described in the
 * comments below.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void fooA(int* iptr){
	/*Assignment Instructions: Print the value and address of the integer pointed to by iptr.*/
	printf("Value of x from fooA: %d\n", *iptr);	// Print the value of the integer pointed to by iptr.
	printf("Address of x from fooA: %p\n", iptr);	// Print the address of the integer pointed to by iptr.
     /*Assignment Instructions: Increment the value of the integer pointed to by iptr by 5*/
	*iptr = *iptr + 5;								// Add 5 to the value pointed to by iptr.
     /*Assignment Instructions: Print the address of iptr itself*/
	printf("Address of iptr: %p\n", &iptr);			// Print the address of iptr itself.
	//printf("Increment the value of the integer pointed to by iptr by 5: %d\n", *iptr);	// Print the new value of iptr.
}


void fooB(int* jptr){
  
     /*Assignment Instructions: Print the value and address of the integer pointed to by jptr*/
	printf("Value of x from fooB: %p\n", *jptr);	// Print the value of the integer pointed to by jptr.
     /*Assignment Instructions: Decrement jptr by 1*/
	*jptr -= 1;										// Decrement *jptr by 1. == *jptr = *jptr - 1;
	//printf("Decrement jptr by 1: %d\n", *jptr);	// Print value of *jptr test.
     /*Assignment Instructions: Print the address of jptr itself*/
	printf("Address of jptr: %p\n", &jptr);			// Print the address of jptr itself.
}


int main(){
    
    /*Assignment Instructions: Declare an integer x and initialize it randomly to a value in [0,10] */
	srand(time(0));									// Initialize random number generator.
	int x;											// Declare integer x.
	int xPtr = &x;									// Declare integer xPtr that points to the address of x.
	x = rand() % 11;								// Assign x a random value in the range of 1-10.
	printf("Value of x: %d\n", x);					// Print the value of x.
	printf("Address of x: %p\n", xPtr);				// Print the address of x with a pointer.
	printf("Also the address of x: %p\n", &x);		// Print the address of x with & operator.
    
    /*Assignment Instructions: Call fooA() with the address of x*/
	fooA(&x);										// Call fooA, passing the address of x as a parameter.
    /*Assignment Instructions: Print the value of x*/
	printf("x + 5: %d\n", x);						// Print the new value of x after being incremented by 5.
	/*Assignment Question: Is the value of x different than the value that was printed at first? Why or why not?*/
	/*Yes, the value is different because the fooA function increments the value stored at the address of x by 5.*/
    /*Assignment Instructions: Call fooB() with the address of x*/
	fooB(&x);										// Call fooB, passing the address of x as a parameter.
    /*Assignment Instructions: Print the value and address of x*/
	printf("x - 1: %d\n", x);						// Print the value of x after being decremented by 1.
	printf("Address of x: %p\n", &x);				// Print the address of x.
	/*Assigment Question: Are the value and address of x different than the value and address that were printed
	before the call to fooB(..)? Why or why not?*/
	/*The value of x is different because the fooB function decrements the value stored at the address of x. However,
	the address is not different, because the fooB function takes a pointer to x as a parameter. and is therefore
	pointing to the same address that x is originally initialized at.*/
    return 0;
}


