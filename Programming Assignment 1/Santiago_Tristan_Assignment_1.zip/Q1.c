/* CS261- Assignment 1 - Q.1*/
/* Name: Tristan Santiago
 * Date: July 6, 2018
 * Solution description: This program generates random IDs and scores for each of the ten
 * students and stores both in the array of students. A detailed explanation of each
 * solution can be found in the comments below.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <assert.h>

struct student{
	int id;
	int score;
};

struct student* allocate(){
     /*Assignment Instructions: Allocate memory for ten students*/
	struct student *p = malloc(10 * sizeof(struct student));	// Adapted from C Pointers Review Video Lecture. 
	assert(p != 0);												// Assert condition to make sure p is not null.
	/*Assignment Instructions: Return the pointer*/
	return p;													// Borrowed from C Pointers Review Video Lecture.
}

void generate(struct student* students){
     /*Assignment Instructions: Generate random and unique IDs and random scores for ten students, 
	IDs being between 1 and 10, scores between 0 and 100*/
	srand(time(0));												// Initialize random number generator.
	for (int i = 0; i < 10; i++)								// For loop to execute for each student ID and random score.
	{
		(students + i)->id = rand() % 11;						// Randomly generate a random ID between 1 and 10.
		(students + i)->score = rand() % 101;					// Randomly generate a score between 0 and 100.
	}
}

void output(struct student* students){
     /*Assignment Instructions: Output information about the ten students in the format:
              ID1 Score1
              ID2 score2
              ID3 score3
              ...
              ID10 score10*/
	struct student s;											// Create new struct called s.
	for (int i = 0; i < 10; i++)								// For loop to execute 10 times per student and score.
	{
		s = students[i];										// Assign each element of the struct to s for each iteration.
		printf("\n%d %d", s.id, s.score);						// Print randomly generated student ID and student score.
	}
}

void summary(struct student* students){
     /*Assignment Instructions: Compute and print the minimum, maximum and average scores of the 
	ten students*/
	int min = students[0].score, max = students[0].score, total = 0, i;
	float avg;													// Variable to hold the value of the average.

	for (i = 0; i < 10; i++)									// For loop to execute for each student ID and score.
	{
		if (students[i].score < min)							// If the current score is less than the current min:
			min = students[i].score;							// Make that score the new min.

		if (students[i].score > max)							// If the current score is greater than the current max:
			max = students[i].score;							// Make that score the new max.

		total += students[i].score;								// Calculate the total and assign to the total variable.
	}
	avg = total / 10;											// Calculate the average and assign to the avg variable.

	printf("\n Min = %d Max = %d Average = %.2f", min, max, avg); // Print the results.
}

void deallocate(struct student* stud){
     /*Assignment Instructions: Deallocate memory from stud*/
	if (stud != NULL)											// If students is not NULL (empty):
		free(stud);												// Free the memory and continue until all memory has been freed.
}

int main(){
    struct student* stud = NULL;
    
    /*Call allocate*/
	stud = allocate();
    /*Call generate*/
	generate(stud);
    /*Call output*/
	output(stud);
    /*Call summary*/
	summary(stud);
    /*Call deallocate*/
	deallocate(stud);
	printf("\n");
    return 0;
}

