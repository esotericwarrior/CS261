/* CS261- Assignment 1 - Q.2*/
/* Name: Tristan Santiago
 * Date: July 6, 2018
 * Solution description: This program initializes three variables: x, y, and z and passes
 * them into the foo function where a number of operations are performed. A detailed
 * explanation of each solution can be found in the comments below.
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int foo(int* a, int* b, int c){
	printf("\nResults from foo\n");						// Print statement.
	printf("Value of x: %d\n", *a);						// Verify that the first parameter passed sucessfully.
	printf("Value of y: %d\n", *b);						// Verify that the second parameter passed successfully.
	printf("Value of z: %d\n", c);						// Verify that the third parameter passed successfully.
    /*Assignment Instructions: Swap the addresses stored in the pointer variables a and b*/


	int * temp = a;										// Copy the value of a into a temp variable.
	a = b;												// Copy the value of b into a.
	b = temp;											// Copy the original value of a into b.
	printf("Swapped value of a: %d\n", *a);				// Print swapped value of a.
	printf("Swapped value of b: %d\n", *b);				// Print swapped value of b.
	
    /*Assignment Instructions: Decrement the value of integer variable c*/
	c -= 1;												// Decrement the value of c by 1. == c = c - 1;
    /*Return c*/
	return c;
}

int main(){
	srand(time(0));										// Initialize random number generator.
	/*Assignment Instructions: Declare three integers x,y and z and initialize them randomly to values in [0,10] */
	int x = rand() % 11;								// Assign x a random value in the range of 1-10.
	int y = rand() % 11;								// Assign y a random value in the range of 1-10.
	int z = rand() % 11;								// Assign z a random value in the range of 1-10.
	int a;												// Integer to hold the return value of foo.

	/*Assignment Instructions: Print the values of x, y and z*/
	printf("Initial values\n");
	printf("Value of x: %d\n", x);						// Print the value of x.
	printf("Value of y: %d\n", y);						// Print the value of y.
	printf("Value of z: %d\n", z);						// Print the value of z.

    /*Call foo() appropriately, passing x,y,z as parameters*/
	a = foo(&x, &y, z);									// Assign the return function from foo to the variable a.
    /*Print the values of x, y and z*/
	printf("\nValues of x, y, and z:");					// Print statement.
	printf("\nx=%d, y=%d, z=%d\n", x, y, z);			// Print the values x, y, and z.
    /*Print the value returned by foo*/
	printf("\nValue returned by foo: %d\n", a);			// Print the value returned by foo.
    
    return 0;
}
    
    
/*Is the return value different than the value of integer z? Why or why not*/
/*Yes, the value returned from foo is different than the value of integer z because a copy of the value
* is returned by foo and not a pointer to the actual value. Therefore, when it's returned to main and
* printed, it is showing the decremented copy, not the value actually stored at the address of z.*/

/*Are the values of x and y different before and after calling the function foo(..)? Why or why not?*/
/*Yes, the values of x and y are different before and after calling the function foo because the foo
* function swaps the pointers of the two values, so the pointers are pointing to different locations
* after the swap occurs, resulting in different values being printed from the foo function.*/

