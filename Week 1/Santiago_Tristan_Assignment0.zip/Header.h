/************************************************************************
* Name: Tristan Santiago												*
* Date: June 30, 1028													*
* OSU email address: santiatr@oregonstate.edu							*
* Course number/section: CS271_400										*
* Assignment 0															*
* Description: This program uses Heron's formula to calculate the area	*
* of a triangle. The program asks the user to enter the three sides of	*
* the triangle before returning the area.								*
************************************************************************/
#pragma once
#ifndef HEADER_H
#define HEADER_H

#include <math.h>
#include <stdio.h> /*stdio : printf, fprintf, sprintf, fgets, fputs*/

// Function Prototype
int findArea(int side1, int side2, int side3);

// Function declaration
int findArea(int side1, int side2, int side3) {
	printf("\nTesting the findArea function:");
	printf("\n");
	int s = (side1 + side2 + side3) / 2;
	int a = sqrt(s*(s - side1)*(s - side2) * (s - side3));
	printf("\nSide 1: %d", side1);
	printf("\nSide 2: %d", side2);
	printf("\nSide 3: %d", side3);
	printf("\nSemiperimeter: %d", s);
	printf("\nArea using Heron's Formula: %d", a);
	printf("\n");
	return 0;
}
#endif